<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH G:\wegsoft\laravel\reserve-api\resources\views/vendor/mail/html/table.blade.php ENDPATH**/ ?>