<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<!-- <img src="https://drive.google.com/file/d/1-jXxdchpGBUqczcWZzOf6ED6Com7_PJp/view?usp=sharing" alt="image"> -->
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH G:\wegsoft\laravel\reserve-api\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>