<?php echo e($slot); ?>

<?php /**PATH G:\wegsoft\laravel\reserve-api\resources\views/vendor/mail/text/table.blade.php ENDPATH**/ ?>