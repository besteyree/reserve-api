<?php $__env->startComponent('mail::message'); ?>

 
# Reservation Summary
 
<?php $__env->startComponent('mail::table'); ?>
|   Metric    | Count         |
| ------------- |:-------------:| 
| Repeat Customers |  <?php echo e($details['reservation_repeated']); ?>  |
| Reservations Seated    | <?php echo e($details['reservation_seated']); ?> |
| Walkins Seated  |<?php echo e($details['is_walkin']); ?> |
| Total Seated    | <?php echo e($details['total_seated']); ?> |



<?php echo $__env->renderComponent(); ?>
 
Thanks,<br>

<?php echo $__env->renderComponent(); ?><?php /**PATH G:\wegsoft\laravel\reserve-api\resources\views/email/gmail.blade.php ENDPATH**/ ?>